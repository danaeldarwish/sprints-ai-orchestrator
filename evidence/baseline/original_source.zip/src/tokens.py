"""Token counting used by the 500-token chunker.

Uses tiktoken's ``cl100k_base`` when its vocabulary is available (it is
downloaded on first use). In a network-restricted environment it falls back to
a regex word/punctuation count, which is within ~25% of cl100k for English.
"""
from __future__ import annotations

import re
from functools import lru_cache

_FALLBACK = re.compile(r"\w+|[^\w\s]")


@lru_cache(maxsize=1)
def _encoder():
    try:
        import tiktoken

        return tiktoken.get_encoding("cl100k_base")
    except Exception:  # offline / blocked download
        return None


def tokenizer_name() -> str:
    """Name of the tokenizer actually in use (reported in the ingestion report)."""
    return "tiktoken:cl100k_base" if _encoder() else "regex-fallback"


def count_tokens(text: str) -> int:
    """Return the number of tokens in ``text``."""
    enc = _encoder()
    if enc is not None:
        return len(enc.encode(text, disallowed_special=()))
    return len(_FALLBACK.findall(text))
