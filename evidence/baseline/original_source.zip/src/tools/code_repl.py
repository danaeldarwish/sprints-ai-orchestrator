"""Sandboxed Python execution for the Assessor Agent (Sprint 1: Python REPL tool).

Curriculum mapping: Module 1 (grading rubric, allowed modules, 5 s limit) and
Module 5 (sandboxing learner code). The discovery call made this a hard
requirement: learner code must never breach platform security.

Defence in depth (each layer is independent):
  1. Static AST screening - blocks non-allow-listed imports, dunder/underscore
     attribute access, introspection builtins (eval, exec, open, getattr, ...).
  2. Separate interpreter process (``python -I -S``), empty environment, temp cwd.
  3. Restricted builtins + allow-listed ``__import__`` inside the child.
  4. OS limits: CPU seconds, address space, file size; wall-clock timeout that
     kills the whole process group; stdout capped.

Limitation: this is not a kernel-level jail. Production should additionally run
the child in a container/gVisor/nsjail with no network namespace.
"""
from __future__ import annotations

import ast
import json
import logging
import os
import re
import resource
import secrets
import signal
import subprocess
import sys
import tempfile
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

from langchain_core.tools import tool

from src import config
from src.schemas import UnableToVerify

log = logging.getLogger("sprints.repl")
_RUNNER = Path(__file__).with_name("_sandbox_runner.py")

ALLOWED_MODULES = frozenset(
    "math statistics itertools functools collections re json string random datetime heapq bisect typing "
    "dataclasses decimal fractions operator textwrap enum copy __future__".split()
)
BLOCKED_NAMES = frozenset(
    "eval exec compile open input breakpoint exit quit getattr setattr delattr globals locals vars "
    "memoryview help dir __import__ __builtins__ __loader__ __spec__".split()
)


@dataclass
class ReplResult:
    """Outcome of one sandboxed run. ``status`` is ok | runtime_error | timeout | blocked | syntax_error."""

    status: str
    stdout: str = ""
    stderr: str = ""
    exit_code: int | None = None
    duration_ms: float = 0.0
    violations: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def validate_submission(code: str) -> list[str]:
    """Static screening. Returns a list of violations (empty = acceptable). Raises SyntaxError."""
    tree = ast.parse(code)
    problems: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name.split(".")[0] not in ALLOWED_MODULES:
                    problems.append(f"line {node.lineno}: import of '{a.name}' is not allowed")
        elif isinstance(node, ast.ImportFrom):
            if node.level or (node.module or "").split(".")[0] not in ALLOWED_MODULES:
                problems.append(f"line {node.lineno}: import from '{node.module}' is not allowed")
        elif isinstance(node, ast.Name):
            if node.id in BLOCKED_NAMES or (node.id.startswith("__") and node.id != "__name__"):
                problems.append(f"line {node.lineno}: use of '{node.id}' is not allowed")
        elif isinstance(node, ast.Attribute):
            if node.attr.startswith("_"):
                problems.append(f"line {node.lineno}: access to private/dunder attribute '{node.attr}' is not allowed")
        elif isinstance(node, ast.Constant) and isinstance(node.value, str):
            if "__" in node.value and node.value != "__main__":
                problems.append(f"line {node.lineno}: strings containing '__' are not allowed (format-string escape)")
    return problems


def _limits() -> None:  # runs in the child between fork and exec
    cpu = int(config.SANDBOX_TIMEOUT_S) + 1
    mem = config.SANDBOX_MEMORY_MB * 1024 * 1024
    resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu))
    resource.setrlimit(resource.RLIMIT_AS, (mem, mem))
    resource.setrlimit(resource.RLIMIT_FSIZE, (1_000_000, 1_000_000))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    os.setsid()


def run_python_sandboxed(code: str, harness: str = "", timeout_s: float | None = None) -> ReplResult:
    """Execute learner ``code`` (then trusted ``harness``) in the sandbox and capture stdout / errors."""
    timeout_s = timeout_s or config.SANDBOX_TIMEOUT_S
    if len(code) > config.SANDBOX_MAX_CODE_CHARS:
        return ReplResult("blocked", violations=[f"submission longer than {config.SANDBOX_MAX_CODE_CHARS} characters"])
    try:
        violations = validate_submission(code)
    except SyntaxError as exc:
        return ReplResult("syntax_error", stderr=f"SyntaxError (line {exc.lineno}): {exc.msg}")
    if violations:
        return ReplResult("blocked", violations=violations, stderr="; ".join(violations))

    payload = json.dumps({"code": code, "harness": harness, "allowed_modules": sorted(ALLOWED_MODULES),
                          "max_output_chars": config.SANDBOX_MAX_OUTPUT_CHARS})
    t0 = time.perf_counter()
    with tempfile.TemporaryDirectory(prefix="sprints-sbx-") as cwd:
        proc = subprocess.Popen(
            [sys.executable, "-I", "-S", str(_RUNNER)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, cwd=cwd, env={"PYTHONIOENCODING": "utf-8", "PATH": "/usr/bin:/bin"},
            preexec_fn=_limits, text=True,
        )
        try:
            out, err = proc.communicate(payload, timeout=timeout_s)
            status = "ok" if proc.returncode == 0 else "runtime_error"
        except subprocess.TimeoutExpired:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            out, err = proc.communicate()
            status = "timeout"
            err = f"Execution exceeded the {timeout_s:g} second limit."
    cap = config.SANDBOX_MAX_OUTPUT_CHARS
    if proc.returncode in (-signal.SIGXCPU, -signal.SIGKILL) and status != "timeout":
        status, err = "timeout", f"CPU time limit exceeded ({timeout_s:g} s)."
    if proc.returncode == 3:
        err = "Output limit exceeded."
    if status == "runtime_error" and "MemoryError" in err:
        err = err.strip() + " (memory limit reached)"
    return ReplResult(status, (out or "")[:cap], (err or "")[:cap], proc.returncode,
                      round((time.perf_counter() - t0) * 1000, 1))


# --------------------------------------------------------- assignment harness
def run_with_tests(code: str, assignment: dict) -> dict:
    """Run ``code`` against an assignment's hidden tests; return evidence for grading.

    The test harness prints its JSON results behind a per-run random nonce that learner code cannot
    know, so a submission cannot fake a passing result by printing one.
    """
    nonce = secrets.token_hex(8) + ":"
    if assignment["kind"] == "function":
        harness = (
            "import json\n_r = []\n"
            f"for _a, _e in {assignment['cases']!r}:\n"
            "    try:\n"
            f"        _g = {assignment['function']}(*_a)\n"
            "        _r.append({'ok': _g == _e, 'input': repr(_a), 'expected': repr(_e), 'got': repr(_g)})\n"
            "    except Exception as _x:\n"
            "        _r.append({'ok': False, 'input': repr(_a), 'expected': repr(_e), 'got': type(_x).__name__ + ': ' + str(_x)})\n"
            f"print({nonce!r} + json.dumps(_r))\n"
        )
    else:
        harness = ""
    run = run_python_sandboxed(code, harness)
    tests: list[dict] = []
    stdout = run.stdout
    if assignment["kind"] == "function" and run.status == "ok":
        lines = stdout.splitlines()
        hit = [ln for ln in lines if ln.startswith(nonce)]
        stdout = "\n".join(ln for ln in lines if not ln.startswith(nonce))
        tests = json.loads(hit[-1][len(nonce):]) if hit else []
    elif assignment["kind"] == "stdout" and run.status == "ok":
        got = [ln.rstrip() for ln in stdout.strip().splitlines()]
        want = assignment["expected_stdout"]
        tests = [{"ok": i < len(got) and got[i] == w, "input": f"line {i + 1}", "expected": w,
                  "got": got[i] if i < len(got) else "<missing>"} for i, w in enumerate(want)]
        if len(got) > len(want):
            tests.append({"ok": False, "input": "extra output", "expected": "<none>", "got": got[len(want)]})
    total = len(tests) or (len(assignment["cases"]) if assignment["kind"] == "function" else len(assignment["expected_stdout"]))
    passed = sum(1 for t in tests if t["ok"])
    return {"run": {**run.to_dict(), "stdout": stdout}, "tests": tests, "passed": passed, "total": total}


@tool
def execute_python(code: str) -> str:
    """Securely execute a Python snippet from a Sprints learner and return its stdout or runtime error as JSON.

    Runs in the Sprints sandbox (allow-listed standard-library imports only, 5 s limit, no files, no network).
    Returns {status, stdout, stderr, duration_ms, violations}. On any internal failure returns
    'unable_to_verify' JSON instead of raising. Used by the Assessor Agent for Module 1 assignments.
    """
    try:
        return json.dumps(run_python_sandboxed(code).to_dict())
    except Exception as exc:
        return UnableToVerify(source="python_repl", message="the code could not be executed safely", detail=str(exc)).model_dump_json()
