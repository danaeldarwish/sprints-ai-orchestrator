"""Child-process runner for learner code. NOT imported by the application.

Launched as ``python -I -S _sandbox_runner.py`` by ``code_repl.py``. Reads a JSON
payload on stdin, executes the learner code with a minimal builtins table and an
allow-listed ``import``, then runs an optional trusted test harness in the same
namespace. Resource limits are applied by the parent before exec.
"""
import builtins
import json
import os
import sys
import traceback

payload = json.loads(sys.stdin.read())
ALLOWED = set(payload["allowed_modules"])
MAX_OUT = payload["max_output_chars"]
_real_import = builtins.__import__
_real_stdout = sys.stdout


class _Capped:
    """stdout wrapper that hard-stops runaway output instead of buffering it."""

    def __init__(self):
        self.n = 0

    def write(self, s):
        self.n += len(s)
        if self.n > MAX_OUT * 4:
            _real_stdout.write("\n[output limit exceeded]\n")
            _real_stdout.flush()
            os._exit(3)
        return _real_stdout.write(s)

    def flush(self):
        _real_stdout.flush()


def _guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
    if level != 0 or name.split(".")[0] not in ALLOWED:
        raise ImportError(f"import of '{name}' is blocked by the Sprints sandbox")
    return _real_import(name, globals, locals, fromlist, level)


_SAFE = (
    "abs all any ascii bin bool bytearray bytes callable chr classmethod complex dict divmod enumerate filter "
    "float format frozenset hasattr hash hex int isinstance issubclass iter len list map max min next object oct "
    "ord pow print property range repr reversed round set slice sorted staticmethod str sum super tuple type zip "
    "Exception ValueError TypeError KeyError IndexError ZeroDivisionError ArithmeticError AttributeError NameError "
    "RuntimeError StopIteration AssertionError NotImplementedError OverflowError LookupError "
    "True False None NotImplemented Ellipsis"
).split()
safe_builtins = {n: getattr(builtins, n) for n in _SAFE}
safe_builtins["__import__"] = _guarded_import
safe_builtins["__build_class__"] = builtins.__build_class__
safe_builtins["__name__"] = "__main__"
ns = {"__builtins__": safe_builtins, "__name__": "__main__"}

sys.stdout = _Capped()


def _fail(exc):
    tb = traceback.extract_tb(exc.__traceback__)
    line = next((f.lineno for f in reversed(tb) if f.filename == "<submission>"), None)
    where = f" (line {line})" if line else ""
    sys.stderr.write(f"{type(exc).__name__}{where}: {exc}\n")
    sys.stderr.flush()
    sys.stdout.flush()
    os._exit(1)


try:
    exec(compile(payload["code"], "<submission>", "exec"), ns)
except BaseException as exc:  # noqa: BLE001 - report everything the learner code raised
    _fail(exc)

if payload.get("harness"):
    try:
        exec(compile(payload["harness"], "<harness>", "exec"), ns)
    except BaseException as exc:  # noqa: BLE001
        _fail(exc)
sys.stdout.flush()
