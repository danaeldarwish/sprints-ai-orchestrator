"""Command-line entry point: live end-to-end demo, interactive chat, and one-off setup commands.

    python -m src.main build-db            # CSV -> SQLite (learners + openings)
    python -m src.main ingest              # curriculum -> ChromaDB (500/50 chunks)
    python -m src.main demo [--verbose] [--auto-approve | --auto-reject]
    python -m src.main chat --learner SPR-1001 [--verbose]

The discovery call asked for a *live* demo of: a curriculum query, secure grading, and routing a student to a
partner opening from live database records. ``demo`` runs exactly that, plus the safety scenes.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from typing import Callable

from langchain_core.messages import HumanMessage
from langgraph.types import Command

from src.agents.orchestrator import build_graph, thread_config

BAR = "=" * 78


def converse(graph, learner_id: str, text: str, reviewer: Callable[[dict], dict], **extra) -> dict:
    """Send one learner message; if the graph pauses for human approval, ask ``reviewer`` and resume."""
    cfg = thread_config(learner_id)
    result = graph.invoke({"messages": [HumanMessage(text)], "learner_id": learner_id, **extra}, cfg)
    while result.get("__interrupt__"):
        payload = result["__interrupt__"][0].value
        print(f"\n  ⏸  GRAPH PAUSED - human approval required ({payload['type']})")
        print(f"     learner: {payload['learner_name']} ({payload['learner_id']})  tier-1 partner(s): {', '.join(payload['tier1_partners'])}")
        decision = reviewer(payload)
        print(f"  ▶  resuming with decision: {json.dumps(decision)}")
        result = graph.invoke(Command(resume=decision), cfg)
    return result


def _scene(n: int, title: str, learner: str, text: str) -> None:
    print(f"\n{BAR}\nSCENE {n}: {title}\n{BAR}\nLearner {learner} says:\n{text}\n")


def _show(result: dict) -> None:
    print(f"[status: {result.get('status')}]  [route: {result.get('route')}]\n")
    print(result["final_answer"])


BUGGY = '''Please grade my clean_scores assignment:
```python
def clean_scores(scores):
    return round(sum(s for s in scores if s) / len(scores), 2)
```'''
FIXED = '''I fixed it, please grade again:
```python
def clean_scores(scores):
    """Return the mean of valid (non-None, non-negative) scores rounded to 2 decimals."""
    valid = [s for s in scores if s is not None and s >= 0]
    if not valid:
        return 0.0
    return round(sum(valid) / len(valid), 2)
```'''
EVIL = '''grade my fizzbuzz
```python
import os
print(os.listdir("/"))
```'''


def run_demo(auto: str | None) -> None:
    graph = build_graph()
    if auto == "reject":
        reviewer = lambda p: {"approved": False, "reviewer": "Nour (Career Advisor)", "note": "Needs portfolio review first."}
    else:
        reviewer = lambda p: {"approved": True, "reviewer": "Nour (Career Advisor)", "note": "Profile verified against records."}
    if auto is None and sys.stdin.isatty():
        def reviewer(p):  # noqa: F811 - interactive override
            print("\n--- draft message awaiting approval ---\n" + p["draft_message"] + "\n---------------------------------------")
            ok = input("  Approve? [y/N] ").strip().lower() == "y"
            return {"approved": ok, "reviewer": "live reviewer", "note": input("  Note: ").strip()}

    q = "How do I make my agent remember each student across sessions?"
    _scene(1, "Curriculum question (Advisor Agent, agentic RAG with self-reflection)", "SPR-1001", q)
    _show(converse(graph, "SPR-1001", q, reviewer))

    _scene(2, "Secure grading, first attempt (Assessor Agent: sandbox -> grade -> judge)", "SPR-1005", BUGGY)
    _show(converse(graph, "SPR-1005", BUGGY, reviewer))
    _scene(3, "Secure grading, improved attempt (same thread, memory persists)", "SPR-1005", FIXED)
    _show(converse(graph, "SPR-1005", FIXED, reviewer))

    _scene(4, "Malicious submission is blocked by the sandbox", "SPR-1009", EVIL)
    _show(converse(graph, "SPR-1009", EVIL, reviewer))

    q = "Which partner openings match me?"
    _scene(5, "Career match from live DB records + tier-1 HITL escalation", "SPR-1013", q)
    _show(converse(graph, "SPR-1013", q, reviewer))

    q = "Any openings for me?"
    _scene(6, "Standard partner only (Swvl): released automatically, no human needed", "SPR-1003", q)
    _show(converse(graph, "SPR-1003", q, reviewer))

    q = "What salary does SPR-1001 want?"
    _scene(7, "Privacy guard: a learner asks about someone else", "SPR-1003", q)
    _show(converse(graph, "SPR-1003", q, reviewer))

    q = "Which partner openings match me?"
    _scene(8, "Graceful fallback: learner record cannot be verified", "SPR-9999", q)
    _show(converse(graph, "SPR-9999", q, reviewer))
    print(f"\n{BAR}\nDemo complete.\n{BAR}")


def run_chat(learner: str) -> None:
    graph = build_graph()

    def reviewer(p: dict) -> dict:
        print("\n--- draft awaiting approval ---\n" + p["draft_message"])
        return {"approved": input("Approve? [y/N] ").strip().lower() == "y", "reviewer": "console reviewer", "note": ""}

    print(f"Sprints Orchestrator - chatting as {learner}. Paste code in ```python fences. Ctrl-D to quit.")
    while True:
        try:
            text = input("\nyou> ")
        except EOFError:
            break
        if text.strip():
            print("\n" + converse(graph, learner, text, reviewer)["final_answer"])


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(prog="sprints", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("command", choices=["demo", "chat", "ingest", "build-db"])
    p.add_argument("--learner", default="SPR-1001")
    p.add_argument("--verbose", action="store_true", help="print the HumanMessage/AIMessage/ToolMessage trace of every node")
    g = p.add_mutually_exclusive_group()
    g.add_argument("--auto-approve", action="store_true")
    g.add_argument("--auto-reject", action="store_true")
    args = p.parse_args(argv)

    if args.verbose:
        h = logging.StreamHandler(sys.stdout)
        h.setFormatter(logging.Formatter("    %(message)s"))
        logging.getLogger("sprints.trace").addHandler(h)
        logging.getLogger("sprints.trace").setLevel(logging.INFO)
    if args.command == "build-db":
        from src.tools.db_queries import build_database
        print(build_database())
    elif args.command == "ingest":
        from src.tools.rag_retriever import ingest_curriculum
        print(ingest_curriculum())
    elif args.command == "chat":
        run_chat(args.learner)
    else:
        run_demo("approve" if args.auto_approve else "reject" if args.auto_reject else None)


if __name__ == "__main__":
    main()
