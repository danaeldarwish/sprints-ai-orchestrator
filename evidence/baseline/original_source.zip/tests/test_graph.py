"""Sprint 2: routing, memory, agentic RAG, HITL, protocol, fallbacks, grounding."""
import logging

import pytest
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langgraph.types import Command

from src.agents.advisor_agent import build_career_message, verify_grounding
from src.agents.orchestrator import build_graph, thread_config
from tests.conftest import BUGGY, GOOD


def test_routes_by_intent(ask):
    assert ask("SPR-1002", "How is a Python assignment scored?")["route"] == "advisor_curriculum"
    assert ask("SPR-1002", "Which job openings match me?")["route"] == "advisor_career"
    assert ask("SPR-1002", GOOD)["route"] == "assessor"
    assert ask("SPR-1002", "")["route"] == "clarify"


def test_memory_persists_per_thread_and_is_isolated(ask, graph):
    ask("SPR-1010", "How is a Python assignment scored?")
    r2 = ask("SPR-1010", "tell me more about it")
    assert r2["turn_count"] == 2 and "assignment" in r2["last_topic"]
    assert "assignment" in r2["search_query"]          # follow-up resolved from remembered topic
    other = ask("SPR-1011", "What chunk size does ingestion use?")
    assert other["turn_count"] == 1
    humans = [m.content for m in other["messages"] if isinstance(m, HumanMessage)]
    assert humans == ["What chunk size does ingestion use?"]
    state = graph.get_state(thread_config("SPR-1010")).values
    assert len([m for m in state["messages"] if isinstance(m, HumanMessage)]) == 2


def test_agentic_rag_reformulates_when_context_insufficient(ask):
    r = ask("SPR-1012", "How do I make my agent remember each student?")
    assert r["retrieval_attempts"] == 2 and r["status"] == "answered"
    assert any("Reformulated" in str(m.content) for m in r["messages"] if isinstance(m, AIMessage))
    assert "MemorySaver" in r["final_answer"]


def test_out_of_scope_question_does_not_hallucinate(ask):
    r = ask("SPR-1012", "what is the weather in Cairo")
    assert r["status"] == "not_in_curriculum" and r["retrieval_attempts"] <= 3
    assert "could not find" in r["final_answer"]


def test_hitl_interrupt_then_approve(graph, ask):
    r = ask("SPR-1013", "Which partner openings match me?")
    payload = r["__interrupt__"][0].value
    assert payload["tier1_partners"] == ["Fawry"] and "OPN-FAWR-AAA" in payload["eligible_openings"]
    assert graph.get_state(thread_config("SPR-1013")).next == ("hitl_gate",)
    done = graph.invoke(Command(resume={"approved": True, "reviewer": "Nour"}), thread_config("SPR-1013"))
    assert done["status"] == "approved_by_human" and "Fawry" in done["final_answer"]


def test_hitl_rejection_withholds_recommendation(graph, ask):
    ask("SPR-1018", "Any openings for me?")
    done = graph.invoke(Command(resume={"approved": False, "reviewer": "Nour"}), thread_config("SPR-1018"))
    assert done["status"] == "rejected_by_human" and "Fawry" not in done["final_answer"]


def test_no_interrupt_without_tier1(ask):
    r = ask("SPR-1003", "Any openings for me?")
    assert "__interrupt__" not in r and r["status"] == "released" and "Swvl" in r["final_answer"]


def test_privacy_and_unknown_learner(ask):
    r = ask("SPR-1003", "What salary does SPR-1001 want?")
    assert r["status"] == "denied" and "30" not in r["final_answer"]
    r = ask("SPR-9999", "Which openings match me?")
    assert r["status"] == "unable_to_verify" and r["final_answer"].startswith("Unable to verify")


def test_db_exception_gives_structured_unable_to_verify(ask, monkeypatch):
    import sqlite3
    from src.tools import db_queries
    monkeypatch.setattr(db_queries, "_connect_ro", lambda: (_ for _ in ()).throw(sqlite3.OperationalError("locked")))
    r = ask("SPR-1002", "Which openings match me?")
    assert r["status"] == "unable_to_verify" and "Unable to verify" in r["final_answer"]


def test_repl_exception_gives_structured_unable_to_verify(ask, monkeypatch):
    from src.agents import assessor_agent
    monkeypatch.setattr(assessor_agent, "run_with_tests", lambda c, a: (_ for _ in ()).throw(OSError("cannot fork")))
    r = ask("SPR-1002", GOOD)
    assert r["status"] == "unable_to_verify" and "python_repl" in r["final_answer"]


def test_grading_end_to_end(ask):
    good, bad = ask("SPR-1005", GOOD), ask("SPR-1005", BUGGY)
    assert good["assessment"]["score"] == 100 and good["assessment"]["pass_status"] == "pass"
    assert bad["assessment"]["pass_status"] == "fail" and "ZeroDivisionError" in bad["final_answer"]


def test_message_protocol_and_trace_logs(ask, caplog):
    caplog.set_level(logging.INFO, logger="sprints.trace")
    r = ask("SPR-1013", "Which partner openings match me?")
    kinds = {type(m) for m in r["messages"]}
    assert {HumanMessage, AIMessage, ToolMessage} <= kinds
    calls = {tc["id"] for m in r["messages"] if isinstance(m, AIMessage) for tc in m.tool_calls}
    assert {m.tool_call_id for m in r["messages"] if isinstance(m, ToolMessage)} <= calls
    log = caplog.text
    assert "node=orchestrator" in log and "ToolMessage" in log and "tool_call: get_learner_profile" in log


def test_grounding_check_catches_invented_facts():
    prof = {"learner_id": "SPR-1001", "name": "A", "bootcamp_track": "T", "completed_modules": 12,
            "python_assignment_score": 95, "target_salary_egp": 30000}
    ops = [{"opening_id": "OPN-FAWR-AAA", "partner": "Fawry", "role": "R", "salary_min_egp": 25000, "salary_max_egp": 48000,
            "eligible": True, "reasons": []}]
    msg = build_career_message(prof, ops)
    assert verify_grounding(msg, prof, ops) == []
    assert verify_grounding(msg + "\nAlso Swvl will hire you.", prof, ops)
    assert verify_grounding(msg + "\nSalary 60,000 EGP.", prof, ops)
    assert verify_grounding(msg + "\nSee OPN-VODA-BE.", prof, ops)
