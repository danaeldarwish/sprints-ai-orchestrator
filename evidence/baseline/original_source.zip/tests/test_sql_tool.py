"""Sprint 1: SQL tools, eligibility rules and the 'Unable to verify' fallback."""
import json
import sqlite3

from src.tools import db_queries as db


def test_profile_returns_modules_salary_and_employers():
    p = json.loads(db.get_learner_profile.invoke({"learner_id": "spr-1001"}))
    assert p["completed_modules"] == 12 and p["target_salary_egp"] == 30000
    assert p["preferred_employers"] == ["Fawry", "Swvl"]


def test_unknown_learner_is_structured_failure_not_exception():
    out = json.loads(db.get_learner_profile.invoke({"learner_id": "SPR-9999"}))
    assert out["status"] == "unable_to_verify" and out["source"] == "learner_record"


def test_sql_tool_is_read_only_and_select_only():
    for bad in ["DROP TABLE learners", "SELECT 1; DELETE FROM learners", "UPDATE learners SET name='x'"]:
        assert json.loads(db.run_readonly_sql.invoke({"query": bad}))["status"] == "unable_to_verify"
    ok = json.loads(db.run_readonly_sql.invoke({"query": "SELECT COUNT(*) AS n FROM learners"}))
    assert ok["rows"][0]["n"] == 25
    assert json.loads(db.get_learner_profile.invoke({"learner_id": "SPR-1001"}))["status"] == "ok"  # table intact


def test_database_exception_triggers_graceful_fallback(monkeypatch):
    monkeypatch.setattr(db, "_connect_ro", lambda: (_ for _ in ()).throw(sqlite3.OperationalError("disk I/O error")))
    for tool, arg in [(db.get_learner_profile, {"learner_id": "SPR-1001"}), (db.list_matching_openings, {"learner_id": "SPR-1001"}),
                      (db.run_readonly_sql, {"query": "SELECT 1"})]:
        assert json.loads(tool.invoke(arg))["status"] == "unable_to_verify"


def _elig(lid):
    return {o["opening_id"]: o for o in json.loads(db.list_matching_openings.invoke({"learner_id": lid}))["openings"]}


def test_eligibility_rules():
    assert _elig("SPR-1001")["OPN-FAWR-AAA"]["eligible"]
    a = _elig("SPR-1025")                      # target 45,000 EGP is above Swvl's 43,200 max
    assert a["OPN-FAWR-AAA"]["eligible"] and not a["OPN-SWVL-AAA"]["eligible"]
    assert "above the band maximum" in a["OPN-SWVL-AAA"]["reasons"][0]
    assert not any(o["eligible"] for o in _elig("SPR-1004").values())   # Needs Review
    assert not any(o["eligible"] for o in _elig("SPR-1021").values())   # Dropped
