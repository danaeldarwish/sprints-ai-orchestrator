"""Test setup: isolate ChromaDB and SQLite in a temp dir *before* the app imports its config."""
import os
import sys
import tempfile
from pathlib import Path

_TMP = tempfile.mkdtemp(prefix="sprints-tests-")
os.environ["SPRINTS_CHROMA_DIR"] = os.path.join(_TMP, "chroma")
os.environ["SPRINTS_DB_PATH"] = os.path.join(_TMP, "learners.db")
os.environ["SPRINTS_LLM"] = "offline"
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest  # noqa: E402
from langchain_core.messages import HumanMessage  # noqa: E402

from src.agents.orchestrator import build_graph, thread_config  # noqa: E402


@pytest.fixture(scope="session")
def graph():
    return build_graph()


@pytest.fixture()
def ask(graph):
    def _ask(learner: str, text: str, **extra):
        return graph.invoke({"messages": [HumanMessage(text)], "learner_id": learner, **extra}, thread_config(learner))

    return _ask


GOOD = '''grade my clean_scores
```python
def clean_scores(scores):
    """Mean of valid scores rounded to 2 decimals."""
    valid = [s for s in scores if s is not None and s >= 0]
    return round(sum(valid) / len(valid), 2) if valid else 0.0
```'''
BUGGY = '''grade my clean_scores
```python
def clean_scores(scores):
    return round(sum(s for s in scores if s) / len(scores), 2)
```'''
