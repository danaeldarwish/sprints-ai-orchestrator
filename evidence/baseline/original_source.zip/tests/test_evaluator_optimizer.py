"""Sprint 2: Evaluator-Optimizer loop with an LLM-as-a-Judge and a hard 3-refinement cap."""
import pytest
from langchain_core.messages import HumanMessage

from src import config
from src.agents.orchestrator import build_graph, thread_config
from src.heuristics import HeuristicReasoner
from src.schemas import AssessmentResult
from tests.conftest import BUGGY, GOOD


class Counting(HeuristicReasoner):
    def __init__(self):
        self.calls, self.judge_calls = 0, 0

    def grade(self, *a, **k):
        self.calls += 1
        return super().grade(*a, **k)

    def judge(self, *a, **k):
        self.judge_calls += 1
        return super().judge(*a, **k)


class Inflater(Counting):
    """Never learns: always over-scores, so the judge must keep rejecting."""

    def grade(self, assignment, code, evidence, judge_issues, refinement):
        self.calls += 1
        return AssessmentResult(score=100, feedback_points=["Passed 6/6 tests. Perfect."], pass_status="pass")


class LearnsFromJudge(Counting):
    """Over-scores first, fixes itself once it sees the judge's issues."""

    def grade(self, assignment, code, evidence, judge_issues, refinement):
        if not judge_issues:
            self.calls += 1
            return AssessmentResult(score=100, feedback_points=["Passed 6/6 tests. Perfect."], pass_status="pass")
        return super().grade(assignment, code, evidence, judge_issues, refinement)


def _run(reasoner, code, lid="SPR-1005"):
    g = build_graph(reasoner=reasoner, warm=False)
    return g.invoke({"messages": [HumanMessage(code)], "learner_id": lid}, thread_config(lid))


def test_honest_grader_approved_first_time():
    r = Counting()
    out = _run(r, GOOD)
    assert (r.calls, r.judge_calls, out["refinement_count"], out["status"]) == (1, 1, 0, "graded")


def test_judge_catches_inflated_grade_and_optimizer_fixes_it():
    r = LearnsFromJudge()
    out = _run(r, BUGGY)
    assert out["refinement_count"] == 1 and out["status"] == "graded"
    assert out["assessment"]["score"] < 100 and out["assessment"]["pass_status"] == "fail"
    assert out["judge"]["approved"]


def test_loop_halts_after_max_three_refinements():
    r = Inflater()
    out = _run(r, BUGGY)
    assert out["refinement_count"] == config.MAX_REFINEMENTS == 3
    assert r.calls == 4 and r.judge_calls == 4          # 1 initial + 3 refinements, then stop
    assert out["status"] == "graded_needs_human_review" and out["needs_human_review"]
    assert "NOT FINAL" in out["final_answer"] and "PASS" not in out["final_answer"]
