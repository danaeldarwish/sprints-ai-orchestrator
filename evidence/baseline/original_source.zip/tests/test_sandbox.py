"""Sprint 1: the Python REPL tool - correctness and the 'strictly sandboxed' requirement."""
import json

import pytest

from src.tools.code_repl import execute_python, run_python_sandboxed as run


def test_captures_stdout():
    r = run("print(sum(range(10)))")
    assert (r.status, r.stdout.strip()) == ("ok", "45")


def test_captures_runtime_error_with_line_number():
    r = run("x = 1\nprint(1/0)")
    assert r.status == "runtime_error" and "ZeroDivisionError (line 2)" in r.stderr


def test_syntax_error_reported():
    assert run("def f(:").status == "syntax_error"


@pytest.mark.parametrize("code", [
    "import os\nprint(os.listdir('/'))",
    "import subprocess",
    "import socket",
    "from os import path",
    "print(open('/etc/passwd').read())",
    "print(eval('1+1'))",
    "exec('print(1)')",
    "print(().__class__.__bases__[0].__subclasses__())",
    "print(getattr(int, 'real'))",
    "print('{0.__class__}'.format(1))",
    "__import__('os')",
    "print(globals())",
])
def test_attacks_are_blocked_before_execution(code):
    r = run(code)
    assert r.status == "blocked" and r.stdout == "" and r.violations


def test_infinite_loop_is_killed():
    r = run("while True: pass", timeout_s=2)
    assert r.status == "timeout" and r.duration_ms < 4000


def test_memory_bomb_is_contained():
    r = run("x = [0] * (10 ** 10)")
    assert r.status == "runtime_error" and "MemoryError" in r.stderr


def test_output_flood_is_capped():
    r = run("while True: print('a' * 1000)", timeout_s=4)
    assert len(r.stdout) <= 4000 and r.status in {"runtime_error", "timeout"}


def test_allowed_stdlib_and_main_guard_work():
    r = run("import math\nif __name__ == '__main__':\n    print(math.sqrt(16))")
    assert r.status == "ok" and r.stdout.strip() == "4.0"


def test_tool_wrapper_returns_json_and_falls_back(monkeypatch):
    assert json.loads(execute_python.invoke({"code": "print(2)"}))["status"] == "ok"
    import src.tools.code_repl as m
    monkeypatch.setattr(m, "run_python_sandboxed", lambda c: (_ for _ in ()).throw(OSError("fork failed")))
    assert json.loads(execute_python.invoke({"code": "print(2)"}))["status"] == "unable_to_verify"
