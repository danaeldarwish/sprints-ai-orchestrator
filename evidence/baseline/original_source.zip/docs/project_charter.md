# Project Charter - Sprints AI Orchestrator

**Sponsor:** Youssef El-Sherif, VP Engineering, Sprints · **Status:** build complete, report/deck in progress

## Problem
The Advanced Agentic AI bootcamp is scaling across MENA. The Student Success Team is overwhelmed by repetitive curriculum questions, manual Python grading and hand-matching graduates to hiring partners (Fawry, Swvl, Vodafone Egypt, e& Egypt).

## Goal and success criteria
* **Business (discovery call):** reduce student wait time by **80%** by automating the question / grading / matching loop.
* **Technical:** one LangGraph StateGraph with typed state and per-learner checkpointing; strictly sandboxed grading; retrieval < 1000 ms; grading loop <= 3 refinements; "Unable to verify" on tool failure; human approval for tier-1 placements.
* **Demo (discovery call):** live end-to-end: curriculum answer, secure grading, partner routing from live DB records.

## Scope
In: ingestion/RAG, SQL ReAct agent, sandboxed REPL, orchestrator, memory, reflection, evaluator-optimizer, HITL, protocol logging, tests, notebook, report, deck, demo.
Out: web UI, production hosting, real partner-openings integration, learner authentication.

## Risks and mitigations
| Risk | Mitigation |
|---|---|
| Hallucinated qualifications sent to employers (client's top fear) | Templates from DB rows + grounding check + HITL for tier-1 |
| Malicious learner code | Layered sandbox, attack-matrix tests |
| Data gaps (25 vs ~500 learners, no curriculum/openings) | Synthetic, labelled stand-ins; confirm with client |
| Cannot reach hosted LLMs in build environment | Provider-agnostic design; offline reasoner; verify live before demo |
| Cost/latency of judge loop | Hard cap of 3 refinements |
| Deck says slides, call says live demo | Deliver both; lead with live demo |

## Assumptions to confirm with the client
Pass mark 70; rubric 70/15/15; Fawry is the only tier-1 partner; target salary is monthly gross EGP; learners may use only the standard library in assignments; real openings feed format.
