# Sprints Multi-Agent AI Career & Assessment Orchestrator

An orchestrator-worker system built with **LangGraph**, **LangChain**, **Pydantic** and **ChromaDB** that
(1) answers curriculum questions with self-reflecting RAG, (2) grades learner Python in a hardened sandbox with an
evaluator-optimizer loop, and (3) matches learners to partner openings from live database records, pausing for human
approval on tier-1 partners (Fawry).

## Quick start (no API key needed)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m src.main build-db           # CSV -> SQLite (learners + openings)
python -m src.main ingest             # curriculum -> ChromaDB (500-token chunks, 50 overlap)
python -m src.main demo --verbose     # live end-to-end demo with the message trace
python -m pytest                      # 60 tests
```
Use a real model: `export OPENAI_API_KEY=... SPRINTS_LLM=openai SPRINTS_EMBEDDINGS=openai` (see *Honest limitations*).
Interactive: `python -m src.main chat --learner SPR-1001`. Notebook: `notebooks/evaluator_optimizer_loop.ipynb` (executed, outputs saved).

## Architecture
```
learner message ──► orchestrator (intent + privacy guard) ──┬─► advisor_retrieve ─► advisor_reflect ─┬─► advisor_answer ─┐
 thread = learner-<ID>   (MemorySaver checkpoint)           │        ▲                               │ insufficient       │
                                                            │        └──── advisor_reformulate ◄─────┘ (max 3 searches)  │
                                                            ├─► advisor_career (ReAct + SQL tools) ─► career_recommend ─► hitl_gate ─► career_finalize ─┤
                                                            │                    (grounding check)     (interrupt if tier-1)                           │
                                                            └─► assessor_run ─► assessor_grade ─► assessor_judge ─┬─► assessor_finalize ──────────────┤
                                                                (sandbox)                  ▲                       │ rejected (max 3 refinements)      ▼
                                                                                           └──── assessor_refine ◄─┘                              finalize ─► END
```
| Brief requirement | Where |
|---|---|
| Ingestion, 500/50 chunking, ChromaDB | `src/tools/rag_retriever.py` |
| Pydantic prompts + parsers (score, feedback_points, pass_status) | `src/schemas.py`, `src/prompts.py` |
| ReAct agent + SQL tool (modules, EGP salary, employers) | `src/tools/db_queries.py`, `build_react_sql_agent` |
| Python REPL tool, stdout / errors | `src/tools/code_repl.py`, `_sandbox_runner.py` |
| StateGraph + TypedDict routing | `src/state.py`, `src/agents/orchestrator.py` |
| MemorySaver, per-student thread IDs | `thread_config()`; `tests/test_graph.py::test_memory_*` |
| Agentic RAG with self-reflection edge | `advisor_agent.py` (reflect / reformulate) |
| Evaluator-Optimizer + judge, max 3 refinements | `assessor_agent.py`, notebook |
| HITL `interrupt` for tier-1 partners | `hitl_gate` |
| Human/AI/Tool message protocol + verbose logs | `src/protocol.py`, `--verbose` |
| Graceful "Unable to verify" | `UnableToVerify` + fallback routes, tested |
| Retrieval < 1000 ms | measured p95 ≈ 1 ms; hard timeout in `retrieve()` |

## Design decisions that answer the client's stated fears
* **No hallucinated careers:** the learner-facing placement text is rendered *from DB rows only*; `verify_grounding` blocks any partner, opening ID or number not in the retrieved records.
* **Privacy:** lookups use only the thread's learner ID; asking about another learner is refused.
* **Sandbox:** AST screening + separate `python -I -S` process + restricted builtins + CPU/memory/file/output limits + wall-clock kill. Test harness results use a per-run nonce so a submission cannot fake passing output.
* **Bounded cost:** refinement cap = 3 (1 initial + 3 refinements = 4 grader calls max); unapproved grades are shown as *provisional* and flagged for a human.

## Assumptions (client data gaps)
* `sprints_learner_db.csv` has **25** learners (the deck mentions ~500); no curriculum files, starter repo or partner-openings data were supplied.
* `data/curriculum_docs/*.md` and the `partner_openings` table are **synthetic**, clearly labelled, and replaceable.
* Pass mark 70 and the 70/15/15 rubric are our choices (documented in Module 1 and `src/rubric.py`).

## Honest limitations
* Built and tested **offline**: language judgements come from a deterministic rule-based reasoner (`src/heuristics.py`) and a hashing embedder. The OpenAI backend (`src/llm.py`) uses the same prompts/parsers and is tested only with a fake chat model, **not against the live API**. Run the demo once with your key before presenting.
* Token counting falls back to a regex approximation when the tiktoken vocabulary cannot be downloaded.
* The sandbox is defence in depth, not a kernel jail; add a container/gVisor for production. `MemorySaver` is in-process; use a SQLite/Postgres checkpointer for production.
* Learner code needing other libraries (e.g. `numpy`) is rejected by design.
